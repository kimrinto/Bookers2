# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '7b7e32662fd638139773e4da8b304c315f8bf3f956485edcf13843d67a178b6b17237170f25bb2b6026f40949c93df49b490398ea7168cb8940389c42065ce26'
